<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class FeriasEventoController extends Controller
{
    //
}
