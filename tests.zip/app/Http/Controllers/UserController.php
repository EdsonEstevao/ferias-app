<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Spatie\Permission\Models\Role;

class UserController extends Controller
{
    //
    public function index()
    {
        $data = [];
        //   $users = User::with('roles')
        //                 ->get()
        //                 ->map(function($user) {
        //                     return [
        //                         'id' => $user->id,
        //                         'name' => $user->name,
        //                         'email' => $user->email,
        //                         'roles' => $user->roles->pluck('name'), // Já retorna array
        //                         'created_at' => $user->created_at->toISOString(),
        //                         'initials' => strtoupper(
        //                             collect(explode(' ', $user->name))
        //                                 ->map(fn($part) => substr($part, 0, 1))
        //                                 ->take(2)
        //                                 ->join('')
        //                         )
        //                     ];
        // });

        $users = User::with('roles')->paginate(10)->withQueryString();

        $roles = Role::all();

        $data = [
            'users' => $users,
            'roles' => $roles
        ];

        // dd($data);


        return view('admin.users.index', $data);
    }

    public function create()
    {
         return view('admin.users.create', [
            'users' => User::with('roles')->get(),
            'roles' => Role::all(),
        ]);
        // return view('admin.users.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'email' => 'required|email|unique:users',
            'password' => 'required|min:6',
            'role' => 'required|exists:roles,name',
        ]);

        $user = User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => bcrypt($request->password),
        ]);

        $user->assignRole($request->role);

        return back()->with('success', 'Usuário criado com sucesso!');
    }

    public function updateRoles(Request $request, User $user)
    {
        $user->syncRoles($request->roles ?? []);
        return back()->with('success', 'Roles atualizadas!');
    }

}
