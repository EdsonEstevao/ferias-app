<x-app-layout>
    <x-slot name="header">
        <div class="flex items-center justify-between">
            <h2 class="text-2xl font-bold leading-tight text-gray-800 dark:text-gray-200">
                Gerenciamento de Usuários
            </h2>
            <a href="{{ route('admin.users.create') }}"
                class="px-4 py-2 text-white bg-blue-600 rounded-lg hover:bg-blue-700 focus:ring-4 focus:ring-blue-300 transition duration-200">
                Novo Usuário
            </a>
        </div>
    </x-slot>

    <div class="py-8">
        <div class="mx-auto max-w-7xl sm:px-6 lg:px-8">
            <!-- Alertas -->
            @if (session('success'))
                <div class="p-4 mb-6 text-green-700 bg-green-100 border-l-4 border-green-500 rounded-md">
                    <div class="flex items-center">
                        <svg class="w-5 h-5 mr-3" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd"
                                d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                                clip-rule="evenodd" />
                        </svg>
                        <span class="font-medium">{{ session('success') }}</span>
                    </div>
                </div>
            @endif

            <div x-data="userManager()" x-init="init()"
                class="overflow-hidden bg-white shadow-sm dark:bg-gray-800 sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    <!-- Card de Filtros e Pesquisa -->
                    <div
                        class="p-6 mb-6 bg-white border border-gray-200 rounded-lg shadow-sm dark:bg-gray-800 dark:border-gray-700">
                        <div class="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                            <div class="flex-1">
                                <div class="relative">
                                    <div class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                                        <svg class="w-5 h-5 text-gray-400" fill="none" stroke="currentColor"
                                            viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                                        </svg>
                                    </div>
                                    <input x-model="searchTerm" @input.debounce.300ms="filterUsers()" type="text"
                                        placeholder="Pesquisar por nome, e-mail ou perfil..."
                                        class="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white">
                                </div>
                            </div>

                            <div class="flex gap-3">
                                <!-- Filtro por Perfil -->
                                <select x-model="roleFilter" @change="filterUsers()"
                                    class="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white">
                                    <option value="">Todos os Perfis</option>
                                    @foreach ($roles as $role)
                                        <option value="{{ $role->name }}">{{ ucfirst($role->name) }}</option>
                                    @endforeach
                                </select>

                                <!-- Botão Limpar Filtros -->
                                <button @click="clearFilters()"
                                    class="px-4 py-2 text-gray-700 bg-gray-200 border border-gray-300 rounded-lg hover:bg-gray-300 dark:bg-gray-700 dark:text-gray-300 dark:border-gray-600 dark:hover:bg-gray-600 transition duration-200">
                                    Limpar
                                </button>
                            </div>
                        </div>

                        <!-- Estatísticas -->
                        <div class="flex flex-wrap gap-4 mt-4 text-sm text-gray-600 dark:text-gray-400">
                            <span x-text="`Total: ${totalUsers} usuários`"></span>
                            <span x-text="`Filtrados: ${filteredUsers} usuários`"></span>
                            <span x-show="searchTerm || roleFilter"
                                x-text="`Mostrando: ${displayedUsers} usuários`"></span>
                        </div>
                    </div>

                    <!-- Tabela de Usuários -->
                    <div class="overflow-hidden border border-gray-200 rounded-lg dark:border-gray-700">
                        <div class="overflow-x-auto">
                            <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                                <thead class="bg-gray-50 dark:bg-gray-700">
                                    <tr>
                                        <th class="px-6 py-3 text-xs font-medium tracking-wider text-left text-gray-500 uppercase dark:text-gray-300 cursor-pointer"
                                            @click="sortBy('name')">
                                            <div class="flex items-center space-x-1">
                                                <span>Usuário</span>
                                                <svg x-show="sortField === 'name' && sortDirection === 'asc'"
                                                    class="w-4 h-4" fill="none" stroke="currentColor"
                                                    viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round"
                                                        stroke-width="2" d="M5 15l7-7 7 7" />
                                                </svg>
                                                <svg x-show="sortField === 'name' && sortDirection === 'desc'"
                                                    class="w-4 h-4" fill="none" stroke="currentColor"
                                                    viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round"
                                                        stroke-width="2" d="M19 9l-7 7-7-7" />
                                                </svg>
                                            </div>
                                        </th>
                                        <th class="px-6 py-3 text-xs font-medium tracking-wider text-left text-gray-500 uppercase dark:text-gray-300 cursor-pointer"
                                            @click="sortBy('email')">
                                            <div class="flex items-center space-x-1">
                                                <span>E-mail</span>
                                                <svg x-show="sortField === 'email' && sortDirection === 'asc'"
                                                    class="w-4 h-4" fill="none" stroke="currentColor"
                                                    viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round"
                                                        stroke-width="2" d="M5 15l7-7 7 7" />
                                                </svg>
                                                <svg x-show="sortField === 'email' && sortDirection === 'desc'"
                                                    class="w-4 h-4" fill="none" stroke="currentColor"
                                                    viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round"
                                                        stroke-width="2" d="M19 9l-7 7-7-7" />
                                                </svg>
                                            </div>
                                        </th>
                                        <th
                                            class="px-6 py-3 text-xs font-medium tracking-wider text-left text-gray-500 uppercase dark:text-gray-300">
                                            Perfis
                                        </th>
                                        <th class="px-6 py-3 text-xs font-medium tracking-wider text-left text-gray-500 uppercase dark:text-gray-300 cursor-pointer"
                                            @click="sortBy('created_at')">
                                            <div class="flex items-center space-x-1">
                                                <span>Data de Cadastro</span>
                                                <svg x-show="sortField === 'created_at' && sortDirection === 'asc'"
                                                    class="w-4 h-4" fill="none" stroke="currentColor"
                                                    viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round"
                                                        stroke-width="2" d="M5 15l7-7 7 7" />
                                                </svg>
                                                <svg x-show="sortField === 'created_at' && sortDirection === 'desc'"
                                                    class="w-4 h-4" fill="none" stroke="currentColor"
                                                    viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round"
                                                        stroke-width="2" d="M19 9l-7 7-7-7" />
                                                </svg>
                                            </div>
                                        </th>
                                        <th
                                            class="px-6 py-3 text-xs font-medium tracking-wider text-left text-gray-500 uppercase dark:text-gray-300">
                                            Ações
                                        </th>
                                    </tr>
                                </thead>
                                <tbody class="bg-white divide-y divide-gray-200 dark:bg-gray-800 dark:divide-gray-700">
                                    <template x-for="user in paginatedUsers" :key="user.id">
                                        <tr class="hover:bg-gray-50 dark:hover:bg-gray-700 transition duration-150">
                                            <td class="px-6 py-4 whitespace-nowrap">
                                                <div class="flex items-center">
                                                    <div class="flex-shrink-0 w-10 h-10">
                                                        <div
                                                            class="flex items-center justify-center w-10 h-10 bg-blue-100 rounded-full dark:bg-blue-900">
                                                            <span
                                                                class="text-sm font-medium text-blue-800 dark:text-blue-200"
                                                                x-text="getInitials(user.name)"></span>
                                                        </div>
                                                    </div>
                                                    <div class="ml-4">
                                                        <div class="text-sm font-medium text-gray-900 dark:text-white"
                                                            x-text="user.name"></div>
                                                    </div>
                                                </div>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap">
                                                <div class="text-sm text-gray-900 dark:text-white"
                                                    x-text="user.email"></div>
                                            </td>
                                            <td class="px-6 py-4">
                                                <div class="flex flex-wrap gap-1">
                                                    <template x-for="role in user.roles" :key="role.name">
                                                        <span
                                                            class="inline-flex px-2 py-1 text-xs font-medium rounded-full"
                                                            :class="getRoleBadgeClass(role.name)">
                                                            <span x-text="role.name"></span>
                                                        </span>
                                                    </template>
                                                    <span x-show="user.roles.length === 0"
                                                        class="inline-flex px-2 py-1 text-xs font-medium text-gray-600 bg-gray-100 rounded-full dark:bg-gray-700 dark:text-gray-400">
                                                        Sem perfil
                                                    </span>
                                                </div>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap">
                                                <div class="text-sm text-gray-500 dark:text-gray-400"
                                                    x-text="formatDate(user.created_at)"></div>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap">
                                                <div class="flex items-center space-x-2">
                                                    <a :href="`/admin/users/${user.id}/edit`"
                                                        class="text-blue-600 hover:text-blue-900 dark:text-blue-400 dark:hover:text-blue-300 transition duration-200">
                                                        <svg class="w-5 h-5" fill="none" stroke="currentColor"
                                                            viewBox="0 0 24 24">
                                                            <path stroke-linecap="round" stroke-linejoin="round"
                                                                stroke-width="2"
                                                                d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                                                        </svg>
                                                    </a>
                                                    <button @click="deleteUser(user)"
                                                        class="text-red-600 hover:text-red-900 dark:text-red-400 dark:hover:text-red-300 transition duration-200">
                                                        <svg class="w-5 h-5" fill="none" stroke="currentColor"
                                                            viewBox="0 0 24 24">
                                                            <path stroke-linecap="round" stroke-linejoin="round"
                                                                stroke-width="2"
                                                                d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                                                        </svg>
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                    </template>

                                    <!-- Estado vazio -->
                                    <tr x-show="filteredUsers === 0">
                                        <td colspan="5" class="px-6 py-12 text-center">
                                            <div class="text-gray-500 dark:text-gray-400">
                                                <svg class="w-12 h-12 mx-auto mb-4 text-gray-300 dark:text-gray-600"
                                                    fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round"
                                                        stroke-width="2"
                                                        d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                                                </svg>
                                                <p class="text-lg font-medium">Nenhum usuário encontrado</p>
                                                <p class="mt-1">Tente ajustar os filtros de pesquisa</p>
                                            </div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                        <!-- Paginação -->
                        <div x-show="totalPages > 1"
                            class="flex items-center justify-between px-6 py-4 bg-gray-50 dark:bg-gray-700">
                            <div class="text-sm text-gray-700 dark:text-gray-300">
                                Mostrando <span x-text="startIndex + 1"></span> a <span
                                    x-text="Math.min(endIndex, filteredUsers)"></span> de <span
                                    x-text="filteredUsers"></span> resultados
                            </div>
                            <div class="flex space-x-2">
                                <button @click="previousPage()" :disabled="currentPage === 1"
                                    :class="{ 'opacity-50 cursor-not-allowed': currentPage === 1 }"
                                    class="px-3 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 dark:bg-gray-600 dark:text-gray-300 dark:border-gray-500 dark:hover:bg-gray-500">
                                    Anterior
                                </button>
                                <div class="flex space-x-1">
                                    <template x-for="page in visiblePages" :key="page">
                                        <button @click="goToPage(page)"
                                            :class="{
                                                'bg-blue-600 text-white': currentPage ===
                                                    page,
                                                'text-gray-700 bg-white hover:bg-gray-50 dark:bg-gray-600 dark:text-gray-300 dark:hover:bg-gray-500': currentPage !==
                                                    page
                                            }"
                                            class="px-3 py-2 text-sm font-medium border border-gray-300 rounded-md dark:border-gray-500"
                                            x-text="page">
                                        </button>
                                    </template>
                                </div>
                                <button @click="nextPage()" :disabled="currentPage === totalPages"
                                    :class="{ 'opacity-50 cursor-not-allowed': currentPage === totalPages }"
                                    class="px-3 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 dark:bg-gray-600 dark:text-gray-300 dark:border-gray-500 dark:hover:bg-gray-500">
                                    Próxima
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        function userManager() {
            return {
                users: {{ Js::from(
                    $users->map(function ($user) {
                        return [
                            'id' => $user->id,
                            'name' => $user->name,
                            'email' => $user->email,
                            'roles' => $user->roles->map(function ($role) {
                                    return ['name' => $role->name];
                                })->toArray(),
                            'created_at' => $user->created_at->toISOString(),
                        ];
                    }),
                ) }},
                searchTerm: '',
                roleFilter: '',
                sortField: 'name',
                sortDirection: 'asc',
                currentPage: 1,
                itemsPerPage: 10,

                // Computed
                get filteredUsers() {
                    let filtered = this.users;

                    // Filtro por pesquisa
                    if (this.searchTerm) {
                        const term = this.searchTerm.toLowerCase();
                        filtered = filtered.filter(user =>
                            user.name.toLowerCase().includes(term) ||
                            user.email.toLowerCase().includes(term) ||
                            user.roles.some(role => role.name.toLowerCase().includes(term))
                        );
                    }

                    // Filtro por perfil
                    if (this.roleFilter) {
                        filtered = filtered.filter(user =>
                            user.roles.some(role => role.name === this.roleFilter)
                        );
                    }

                    // Ordenação
                    filtered.sort((a, b) => {
                        let aValue = a[this.sortField];
                        let bValue = b[this.sortField];

                        if (this.sortField === 'created_at') {
                            aValue = new Date(aValue);
                            bValue = new Date(bValue);
                        } else {
                            aValue = aValue?.toString().toLowerCase() || '';
                            bValue = bValue?.toString().toLowerCase() || '';
                        }

                        if (aValue < bValue) return this.sortDirection === 'asc' ? -1 : 1;
                        if (aValue > bValue) return this.sortDirection === 'asc' ? 1 : -1;
                        return 0;
                    });

                    return filtered;
                },

                get totalUsers() {
                    return this.users.length;
                },

                get displayedUsers() {
                    return this.filteredUsers.length;
                },

                get totalPages() {
                    return Math.ceil(this.filteredUsers.length / this.itemsPerPage);
                },

                get paginatedUsers() {
                    const start = (this.currentPage - 1) * this.itemsPerPage;
                    const end = start + this.itemsPerPage;
                    return this.filteredUsers.slice(start, end);
                },

                get startIndex() {
                    return (this.currentPage - 1) * this.itemsPerPage;
                },

                get endIndex() {
                    return Math.min(this.startIndex + this.itemsPerPage, this.filteredUsers.length);
                },

                get visiblePages() {
                    const pages = [];
                    const total = this.totalPages;
                    const current = this.currentPage;

                    if (total <= 7) {
                        for (let i = 1; i <= total; i++) pages.push(i);
                    } else {
                        if (current <= 4) {
                            for (let i = 1; i <= 5; i++) pages.push(i);
                            pages.push('...');
                            pages.push(total);
                        } else if (current >= total - 3) {
                            pages.push(1);
                            pages.push('...');
                            for (let i = total - 4; i <= total; i++) pages.push(i);
                        } else {
                            pages.push(1);
                            pages.push('...');
                            for (let i = current - 1; i <= current + 1; i++) pages.push(i);
                            pages.push('...');
                            pages.push(total);
                        }
                    }

                    return pages;
                },

                // Methods
                init() {
                    console.log('User manager initialized with', this.totalUsers, 'users');
                },

                filterUsers() {
                    this.currentPage = 1;
                },

                clearFilters() {
                    this.searchTerm = '';
                    this.roleFilter = '';
                    this.currentPage = 1;
                },

                sortBy(field) {
                    if (this.sortField === field) {
                        this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
                    } else {
                        this.sortField = field;
                        this.sortDirection = 'asc';
                    }
                },

                previousPage() {
                    if (this.currentPage > 1) {
                        this.currentPage--;
                    }
                },

                nextPage() {
                    if (this.currentPage < this.totalPages) {
                        this.currentPage++;
                    }
                },

                goToPage(page) {
                    if (page !== '...') {
                        this.currentPage = page;
                    }
                },

                getInitials(name) {
                    return name.split(' ').map(n => n[0]).join('').toUpperCase().substring(0, 2);
                },

                getRoleBadgeClass(roleName) {
                    const classes = {
                        'admin': 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200',
                        'manager': 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200',
                        'user': 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200',
                        'editor': 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200',
                    };
                    return classes[roleName] || 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300';
                },

                formatDate(dateString) {
                    const date = new Date(dateString);
                    return date.toLocaleDateString('pt-BR');
                },

                deleteUser(user) {
                    if (confirm(`Tem certeza que deseja excluir o usuário "${user.name}"?`)) {
                        // Aqui você implementaria a chamada AJAX para deletar o usuário
                        console.log('Deletando usuário:', user.id);
                        // fetch(`/admin/users/${user.id}`, { method: 'DELETE' })
                        // .then(response => response.json())
                        // .then(data => {
                        //     this.users = this.users.filter(u => u.id !== user.id);
                        // });
                    }
                }
            }
        }
    </script>
</x-app-layout>
