<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\EventServiceProvider::class,
    App\Providers\HelperServiceProvider::class,
    App\Providers\UserActivityServiceProvider::class,
];
