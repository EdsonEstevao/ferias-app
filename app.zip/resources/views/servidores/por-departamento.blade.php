<x-app-layout>
    <div class="container px-4 py-8 mx-auto">
        <!-- Cabeçalho -->
        <div class="flex items-center justify-between mb-8">
            <div>
                <h1 class="text-3xl font-bold text-gray-900">Servidores por Departamento</h1>
                <p class="text-gray-600">Visualização agrupada por departamento</p>
            </div>
            <div class="flex gap-3">
                <a href="{{ route('servidores.index') }}"
                    class="inline-flex items-center px-4 py-2 text-gray-700 transition-colors border border-gray-300 rounded-lg hover:bg-gray-50">
                    ← Voltar para Lista
                </a>
                <a href="{{ route('servidores.import.form') }}"
                    class="inline-flex items-center px-4 py-2 text-white transition-colors bg-blue-600 rounded-lg hover:bg-blue-700">
                    📤 Importar
                </a>
            </div>
        </div>

        <!-- Estatísticas -->
        <div class="grid grid-cols-1 gap-4 mb-8 md:grid-cols-4">
            <div class="p-4 bg-white border border-gray-200 shadow-sm rounded-xl">
                <div class="text-2xl font-bold text-blue-600">{{ $servidoresPorDepartamento->count() }}</div>
                <div class="font-medium text-blue-700">Departamentos</div>
            </div>
            <div class="p-4 bg-white border border-gray-200 shadow-sm rounded-xl">
                <div class="text-2xl font-bold text-green-600">{{ $servidoresPorDepartamento->flatten()->count() }}
                </div>
                <div class="font-medium text-green-700">Total Servidores</div>
            </div>
            <div class="p-4 bg-white border border-gray-200 shadow-sm rounded-xl">
                @php
                    $departamentoMaisPopuloso = $servidoresPorDepartamento
                        ->sortByDesc(function ($servidores) {
                            return $servidores->count();
                        })
                        ->first();
                @endphp
                <div class="text-2xl font-bold text-purple-600">
                    {{ $departamentoMaisPopuloso ? $departamentoMaisPopuloso->count() : 0 }}
                </div>
                <div class="text-sm font-medium text-purple-700">Maior Departamento</div>
            </div>
            <div class="p-4 bg-white border border-gray-200 shadow-sm rounded-xl">
                @php
                    $departamentosComUm = $servidoresPorDepartamento
                        ->filter(function ($servidores) {
                            return $servidores->count() === 1;
                        })
                        ->count();
                @endphp
                <div class="text-2xl font-bold text-orange-600">{{ $departamentosComUm }}</div>
                <div class="text-sm font-medium text-orange-700">Deptos. com 1 servidor</div>
            </div>
        </div>

        <!-- Filtro e Busca -->
        <div class="p-6 mb-6 bg-white border border-gray-200 shadow-sm rounded-xl">
            <div class="flex flex-col items-start justify-between gap-4 md:flex-row md:items-center">
                <div class="flex-1 w-full md:w-auto">
                    <input type="text" id="searchInput" placeholder="🔍 Buscar departamento ou servidor..."
                        class="w-full px-4 py-2 border border-gray-300 rounded-lg md:w-80 focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                </div>
                <div class="flex gap-2">
                    <button id="btnExpandAll"
                        class="inline-flex items-center px-4 py-2 text-sm text-white transition-colors bg-green-600 rounded-lg hover:bg-green-700">
                        📂 Expandir Todos
                    </button>
                    <button id="btnCollapseAll"
                        class="inline-flex items-center px-4 py-2 text-sm text-white transition-colors bg-gray-600 rounded-lg hover:bg-gray-700">
                        📁 Recolher Todos
                    </button>
                </div>
            </div>
        </div>

        <!-- Lista de Departamentos -->
        <div class="space-y-6" id="departamentosContainer">
            @forelse($servidoresPorDepartamento as $departamento => $servidores)
                @include('servidores.partials.departamento-card', [
                    'departamento' => $departamento ?: 'SEM DEPARTAMENTO',
                    'servidores' => $servidores,
                    'count' => $servidores->count(),
                ])
            @empty
                <div class="p-8 text-center bg-white border border-gray-200 shadow-sm rounded-xl">
                    <svg class="w-16 h-16 mx-auto mb-4 text-gray-400" fill="none" stroke="currentColor"
                        viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
                    </svg>
                    <h3 class="mb-2 text-lg font-medium text-gray-900">Nenhum servidor encontrado</h3>
                    <p class="text-gray-600">Não há servidores ativos para exibir.</p>
                </div>
            @endforelse
        </div>
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const searchInput = document.getElementById('searchInput');
            const departamentosContainer = document.getElementById('departamentosContainer');
            const btnExpandAll = document.getElementById('btnExpandAll');
            const btnCollapseAll = document.getElementById('btnCollapseAll');

            // Função de busca
            searchInput.addEventListener('input', function(e) {
                const searchTerm = e.target.value.toLowerCase();
                const cards = departamentosContainer.querySelectorAll('.departamento-card');

                cards.forEach(card => {
                    const departamento = card.querySelector('.departamento-nome').textContent
                        .toLowerCase();
                    const servidores = card.querySelectorAll('.servidor-nome');
                    let hasMatch = departamento.includes(searchTerm);

                    // Verifica se algum servidor corresponde à busca
                    if (!hasMatch) {
                        servidores.forEach(servidor => {
                            if (servidor.textContent.toLowerCase().includes(searchTerm)) {
                                hasMatch = true;
                            }
                        });
                    }

                    card.style.display = hasMatch ? 'block' : 'none';

                    // Se encontrou e está recolhido, expande
                    if (hasMatch && card.classList.contains('collapsed')) {
                        toggleDepartamento(card);
                    }
                });
            });

            // Expandir/Recolher todos
            btnExpandAll.addEventListener('click', function() {
                const cards = departamentosContainer.querySelectorAll('.departamento-card');
                cards.forEach(card => {
                    if (card.classList.contains('collapsed')) {
                        toggleDepartamento(card);
                    }
                });
            });

            btnCollapseAll.addEventListener('click', function() {
                const cards = departamentosContainer.querySelectorAll('.departamento-card');
                cards.forEach(card => {
                    if (!card.classList.contains('collapsed')) {
                        toggleDepartamento(card);
                    }
                });
            });

            // Função para alternar estado do departamento
            function toggleDepartamento(card) {
                const content = card.querySelector('.departamento-content');
                const icon = card.querySelector('.toggle-icon');

                if (card.classList.contains('collapsed')) {
                    content.classList.remove('hidden');
                    icon.innerHTML = '▼';
                    card.classList.remove('collapsed');
                } else {
                    content.classList.add('hidden');
                    icon.innerHTML = '▶';
                    card.classList.add('collapsed');
                }
            }

            // Adiciona evento de clique para cada card
            departamentosContainer.addEventListener('click', function(e) {
                if (e.target.closest('.departamento-header')) {
                    const card = e.target.closest('.departamento-card');
                    toggleDepartamento(card);
                }
            });
        });
    </script>
</x-app-layout>
