<x-app-layout>
    <div class="container px-4 py-8 mx-auto">
        <div class="max-w-4xl mx-auto">
            <!-- Cabeçalho -->
            <div class="flex items-center justify-between mb-6">
                <div>
                    <h1 class="text-3xl font-bold text-gray-900">Detalhes do Servidor</h1>
                    <p class="text-gray-600">Informações completas do servidor</p>
                </div>
                <div class="flex gap-2">
                    <a href="{{ route('servidores.edit', $servidor) }}"
                        class="inline-flex items-center px-4 py-2 text-white transition-colors bg-blue-600 rounded-lg hover:bg-blue-700">
                        <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                        </svg>
                        Editar
                    </a>
                    <a href="{{ route('servidores.index') }}"
                        class="inline-flex items-center px-4 py-2 text-gray-700 transition-colors border border-gray-300 rounded-lg hover:bg-gray-50">
                        ← Voltar
                    </a>
                </div>
            </div>


            <!-- Card de Informações -->
            <div class="p-6 mb-6 bg-white border border-gray-200 shadow-sm rounded-xl">
                <h2 class="mb-4 text-xl font-semibold text-gray-900">📋 Dados Pessoais</h2>

                <div class="grid grid-cols-1 gap-6 md:grid-cols-2">
                    <div>
                        <label class="block mb-1 text-sm font-medium text-gray-700">Nome Completo</label>
                        <p class="text-lg text-gray-900">{{ $servidor->nome }}</p>
                    </div>

                    <div>
                        <label class="block mb-1 text-sm font-medium text-gray-700">Matrícula</label>
                        <p class="font-mono text-gray-900">{{ $servidor->matricula }}</p>
                    </div>

                    <div>
                        <label class="block mb-1 text-sm font-medium text-gray-700">CPF</label>
                        <p class="text-gray-900">{{ $servidor->cpf ?? 'Não informado' }}</p>
                    </div>

                    <div>
                        <label class="block mb-1 text-sm font-medium text-gray-700">Email</label>
                        <p class="text-gray-900">{{ $servidor->email ?? 'Não informado' }}</p>
                    </div>

                    <div>
                        <label class="block mb-1 text-sm font-medium text-gray-700">Telefone</label>
                        <p class="text-gray-900">{{ $servidor->telefone ?? 'Não informado' }}</p>
                    </div>
                </div>
            </div>

            <!-- Vínculo Atual -->
            @if ($servidor->vinculos()->ativos()->count() > 0)

                <div class="p-6 mb-6 bg-white border border-gray-200 shadow-sm rounded-xl">
                    <h2 class="mb-4 text-xl font-semibold text-gray-900">🏢 Vínculo Atual</h2>

                    <div class="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">

                        <div>
                            <label class="block mb-1 text-sm font-medium text-gray-700">Secretaria</label>
                            <p class="text-gray-900">{{ $vinculoAtual->secretaria }}</p>
                        </div>

                        <div>
                            <label class="block mb-1 text-sm font-medium text-gray-700">Lotação</label>
                            <p class="text-gray-900">{{ $vinculoAtual->lotacao }}</p>
                        </div>

                        <div>
                            <label class="block mb-1 text-sm font-medium text-gray-700">Cargo</label>
                            <p class="text-gray-900">{{ $vinculoAtual->cargo }}</p>
                        </div>

                        <div>
                            <label class="block mb-1 text-sm font-medium text-gray-700">Departamento</label>
                            <p class="text-gray-900">{{ $vinculoAtual->departamento ?? 'Não informado' }}</p>
                        </div>

                        <div>
                            <label class="block mb-1 text-sm font-medium text-gray-700">Sexo</label>
                            <p class="text-gray-900">{{ $vinculoAtual->sexo ?? 'Não informado' }}</p>
                        </div>

                        <div>
                            <label class="block mb-1 text-sm font-medium text-gray-700">Tipo de Servidor</label>
                            <div class="flex flex-wrap gap-1">
                                @foreach ($vinculoAtual->tipo_servidor as $tipo)
                                    <span
                                        class="inline-block px-2 py-1 rounded-full text-xs font-medium
                            {{ $tipo == 'interno' ? 'bg-blue-100 text-blue-800' : '' }}
                            {{ $tipo == 'cedido' ? 'bg-green-100 text-green-800' : '' }}
                            {{ $tipo == 'federal' ? 'bg-purple-100 text-purple-800' : '' }}
                            {{ $tipo == 'regional' ? 'bg-orange-100 text-orange-800' : '' }}
                            {{ $tipo == 'disponibilizado' ? 'bg-red-100 text-red-800' : '' }}">
                                        {{ $tipo }}
                                    </span>
                                @endforeach
                            </div>
                        </div>
                    </div>
                </div>
            @else
                <div class="p-6 mb-6 border border-yellow-200 bg-yellow-50 rounded-xl">

                    <div class="p-4 mb-6 border border-yellow-200 rounded-lg bg-yellow-50">
                        <div class="flex items-center">
                            <svg class="w-5 h-5 mr-3 text-yellow-600" fill="none" stroke="currentColor"
                                viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L4.35 16.5c-.77.833.192 2.5 1.732 2.5z" />
                            </svg>
                            <div>
                                <p class="text-yellow-800">Este servidor não possui vínculo ativo.</p>
                                <a href="{{ route('servidores.nomeacao.create', $servidor) }}"
                                    class="inline-flex items-center px-4 py-2 mt-2 text-sm text-white transition-colors bg-green-600 rounded-lg hover:bg-green-700">
                                    ➕ Cadastrar Nomeação
                                </a>
                            </div>
                        </div>
                    </div>

                </div>
            @endif

            <!-- Histórico de Vínculos -->
            @if ($servidor->vinculos->count() > 1)
                <div class="p-6 bg-white border border-gray-200 shadow-sm rounded-xl">
                    <h2 class="mb-4 text-xl font-semibold text-gray-900">📜 Histórico de Vínculos</h2>

                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="px-4 py-3 text-xs font-medium text-left text-gray-500 uppercase">
                                        Secretaria
                                    </th>
                                    <th class="px-4 py-3 text-xs font-medium text-left text-gray-500 uppercase">Lotação
                                    </th>
                                    <th class="px-4 py-3 text-xs font-medium text-left text-gray-500 uppercase">Cargo
                                    </th>
                                    <th class="px-4 py-3 text-xs font-medium text-left text-gray-500 uppercase">Tipo
                                    </th>
                                    <th class="px-4 py-3 text-xs font-medium text-left text-gray-500 uppercase">Data
                                    </th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-200">
                                @foreach ($servidor->vinculos->skip(0) as $vinculo)
                                    <tr>
                                        <td class="px-4 py-3 text-sm text-gray-900">{{ $vinculo->secretaria }}</td>
                                        <td class="px-4 py-3 text-sm text-gray-900">{{ $vinculo->lotacao }}</td>
                                        <td class="px-4 py-3 text-sm text-gray-900">{{ $vinculo->cargo }}</td>
                                        <td class="px-4 py-3 text-sm">
                                            <div class="flex flex-wrap gap-1">
                                                @foreach ($vinculo->tipo_servidor as $tipo)
                                                    <span
                                                        class="inline-block px-2 py-1 text-xs font-medium text-gray-800 bg-gray-100 rounded-full">
                                                        {{ $tipo }}
                                                    </span>
                                                @endforeach
                                            </div>
                                        </td>
                                        <td class="px-4 py-3 text-sm text-gray-500">
                                            {{ date('d/m/Y', strtotime($vinculo->data_movimentacao)) }}
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            @endif
        </div>
    </div>
</x-app-layout>
