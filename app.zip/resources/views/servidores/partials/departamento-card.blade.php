<div class="overflow-hidden bg-white border border-gray-200 shadow-sm departamento-card rounded-xl">
    <!-- Cabeçalho do Departamento -->
    <div
        class="p-6 transition-all duration-200 border-b border-gray-200 cursor-pointer departamento-header bg-gradient-to-r from-blue-50 to-indigo-50 hover:from-blue-100 hover:to-indigo-100">
        <div class="flex items-center justify-between">
            <div class="flex items-center gap-4">
                <div class="flex-shrink-0">
                    <div class="flex items-center justify-center w-12 h-12 bg-blue-600 rounded-lg">
                        <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                        </svg>
                    </div>
                </div>
                <div>
                    <h3 class="text-xl font-bold text-gray-900 departamento-nome">{{ $departamento }}</h3>
                    <p class="flex items-center gap-2 mt-1 text-gray-600">
                        <span
                            class="inline-flex items-center px-2 py-1 text-xs font-medium text-blue-800 bg-blue-100 rounded-full">
                            📊 {{ $count }} servidor{{ $count > 1 ? 'es' : '' }}
                        </span>
                        @if ($count == 1)
                            <span
                                class="inline-flex items-center px-2 py-1 text-xs font-medium text-yellow-800 bg-yellow-100 rounded-full">
                                ⚠️ Único servidor
                            </span>
                        @endif
                    </p>
                </div>
            </div>
            <div class="flex items-center gap-3">
                <span class="font-mono text-gray-600 toggle-icon">▼</span>
            </div>
        </div>
    </div>

    <!-- Conteúdo - Lista de Servidores -->
    <div class="departamento-content">
        <div class="p-6">
            <div class="grid gap-3">
                @foreach ($servidores as $vinculo)
                    <div
                        class="flex items-center justify-between p-4 transition-colors border border-gray-200 rounded-lg servidor-item hover:bg-gray-50 group">
                        <div class="flex items-center flex-1 gap-4">
                            <!-- Avatar -->
                            <div class="flex-shrink-0">
                                <div
                                    class="flex items-center justify-center w-10 h-10 text-sm font-semibold text-white rounded-full bg-gradient-to-r from-purple-500 to-pink-500">
                                    {{ substr($vinculo->servidor->nome, 0, 1) }}{{ substr(strstr($vinculo->servidor->nome, ' ') ?: '', 1, 1) }}
                                </div>
                            </div>

                            <!-- Informações do Servidor -->
                            <div class="flex-1 min-w-0">
                                <h4 class="font-medium text-gray-900 truncate servidor-nome">
                                    {{ $vinculo->servidor->nome }}
                                </h4>
                                <div class="flex flex-wrap gap-2 mt-1">
                                    <span
                                        class="inline-flex items-center px-2 py-1 text-xs font-medium text-gray-800 bg-gray-100 rounded">
                                        🆔 {{ $vinculo->servidor->matricula }}
                                    </span>
                                    <span
                                        class="inline-flex items-center px-2 py-1 text-xs font-medium text-green-800 bg-green-100 rounded">
                                        💼 {{ $vinculo->cargo }}
                                    </span>
                                    @foreach ($vinculo->tipo_servidor as $tipo)
                                        <span
                                            class="inline-flex items-center px-2 py-1 rounded text-xs font-medium
                                    {{ $tipo == 'interno' ? 'bg-blue-100 text-blue-800' : '' }}
                                    {{ $tipo == 'cedido' ? 'bg-green-100 text-green-800' : '' }}
                                    {{ $tipo == 'federal' ? 'bg-purple-100 text-purple-800' : '' }}
                                    {{ $tipo == 'regional' ? 'bg-orange-100 text-orange-800' : '' }}
                                    {{ $tipo == 'disponibilizado' ? 'bg-red-100 text-red-800' : '' }}">
                                            {{ $tipo }}
                                        </span>
                                    @endforeach
                                </div>
                            </div>
                        </div>

                        <!-- Ações -->
                        <div class="flex items-center gap-2 transition-opacity opacity-0 group-hover:opacity-100">
                            <a href="{{ route('servidores.show', $vinculo->servidor) }}"
                                class="inline-flex items-center px-3 py-1 text-xs text-white transition-colors bg-blue-600 rounded-lg hover:bg-blue-700">
                                👁️ Ver
                            </a>
                            <a href="{{ route('servidores.edit', $vinculo->servidor) }}"
                                class="inline-flex items-center px-3 py-1 text-xs text-white transition-colors bg-green-600 rounded-lg hover:bg-green-700">
                                ✏️ Editar
                            </a>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </div>
</div>
