<!-- quando não encontrar a página -->
<x-errors-layout title="Página Não Encontrada" type="error" :showContact="false"
    message="Desculpe, a página que você está procurando não existe">

</x-errors-layout>
